package com.example.microbus3d;

import android.app.Activity;
import android.os.Bundle;
import android.opengl.GLSurfaceView;
import android.view.MotionEvent;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.graphics.drawable.GradientDrawable;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioTrack;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.media.MediaPlayer;
import android.widget.LinearLayout;
import android.widget.Toast;
import android.content.ClipData;
import java.util.ArrayList;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView.Renderer;
import android.opengl.Matrix;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;
import java.util.Random;

public class MainActivity extends Activity {
    private GameView game;
    private final ArrayList<Uri> radioTracks = new ArrayList<>();
    private MediaPlayer radioPlayer;
    private int radioIndex = 0;
    private TextView radioTrackLabel;
    private TextView radioPlayButton;
    private LinearLayout radioPanel;
    private boolean radioPreparing = false;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        FrameLayout root = new FrameLayout(this);
        game = new GameView(this);
        root.addView(game);
        TextView title = new TextView(this);
        title.setText("ميكروباص مصر 3D  •  القاهرة ⇦ طريق إسكندرية");
        title.setTextColor(Color.WHITE); title.setTextSize(15); title.setTypeface(null, Typeface.BOLD);
        title.setGravity(Gravity.CENTER);
        title.setPadding(18,8,18,8);
        GradientDrawable bg = new GradientDrawable(); bg.setColor(0xB820252B); bg.setCornerRadius(28);
        title.setBackground(bg);
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);
        tp.topMargin=14; root.addView(title,tp);

        TextView hint = new TextView(this);
        hint.setText("لف الدركسيون للتوجيه  •  بنزين وفرامل  •  فتيس يدوي");
        hint.setTextColor(Color.WHITE); hint.setTextSize(12); hint.setGravity(Gravity.CENTER);
        hint.setPadding(14,8,14,8);
        GradientDrawable hb = new GradientDrawable(); hb.setColor(0xB820252B); hb.setCornerRadius(24); hint.setBackground(hb);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        hp.bottomMargin=14; root.addView(hint,hp);

        TextView status = new TextView(this);
        status.setText("السرعة: 0 كم/س");
        status.setTextColor(Color.WHITE); status.setTextSize(14); status.setTypeface(null, Typeface.BOLD);
        status.setGravity(Gravity.CENTER); status.setPadding(14,8,14,8);
        status.setBackground(round(0xB820252B));
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.LEFT);
        sp.leftMargin=18; sp.topMargin=18; root.addView(status,sp);
        game.statusLabel = status;

        TextView rpm = new TextView(this);
        rpm.setText("RPM  ▰▱▱▱▱▱");
        rpm.setTextColor(Color.WHITE); rpm.setTextSize(13); rpm.setTypeface(null, Typeface.BOLD);
        rpm.setGravity(Gravity.CENTER); rpm.setPadding(16,10,16,10);
        rpm.setBackground(round(0xD91B252D));
        FrameLayout.LayoutParams rp = new FrameLayout.LayoutParams(-2,-2,Gravity.BOTTOM|Gravity.CENTER_HORIZONTAL);
        rp.bottomMargin=174; root.addView(rpm,rp);
        game.rpmLabel = rpm;

        TextView gas = new TextView(this);
        gas.setText("بنزين ▲"); gas.setTextColor(Color.WHITE); gas.setTextSize(16); gas.setTypeface(null,Typeface.BOLD);
        gas.setGravity(Gravity.CENTER); gas.setBackground(round(0xDD16834A));
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(150,110,Gravity.RIGHT|Gravity.BOTTOM);
        gp.rightMargin=24; gp.bottomMargin=70; root.addView(gas,gp);
        gas.setOnTouchListener((v,e)-> { game.gas = e.getAction()!=MotionEvent.ACTION_UP && e.getAction()!=MotionEvent.ACTION_CANCEL; return true; });

        TextView brake = new TextView(this);
        brake.setText("فرامل ■"); brake.setTextColor(Color.WHITE); brake.setTextSize(14); brake.setTypeface(null,Typeface.BOLD);
        brake.setGravity(Gravity.CENTER); brake.setBackground(round(0xDDAD302A));
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(110,80,Gravity.RIGHT|Gravity.BOTTOM);
        bp.rightMargin=190; bp.bottomMargin=70; root.addView(brake,bp);
        brake.setOnTouchListener((v,e)-> { game.brake = e.getAction()!=MotionEvent.ACTION_UP && e.getAction()!=MotionEvent.ACTION_CANCEL; return true; });

        TextView gear = new TextView(this);
        gear.setText("فتيس\nN");
        gear.setTextColor(Color.WHITE); gear.setTextSize(14); gear.setTypeface(null,Typeface.BOLD);
        gear.setGravity(Gravity.CENTER); gear.setBackground(round(0xDD34495E));
        FrameLayout.LayoutParams fp = new FrameLayout.LayoutParams(84,84,Gravity.LEFT|Gravity.BOTTOM);
        fp.leftMargin=28; fp.bottomMargin=26; root.addView(gear,fp);
        gear.setOnClickListener(v -> {
            game.gear = (game.gear + 1) % 4;
            String[] names={"N","1","2","R"};
            gear.setText("فتيس\\n"+names[game.gear]);
        });

        TextView camera = new TextView(this);
        camera.setText("📷 خارجية");
        camera.setTextColor(Color.WHITE); camera.setTextSize(13); camera.setTypeface(null,Typeface.BOLD);
        camera.setGravity(Gravity.CENTER); camera.setPadding(16,10,16,10);
        camera.setBackground(round(0xDD34495E));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT);
        cp.rightMargin=18; cp.topMargin=70; root.addView(camera,cp);
        camera.setOnClickListener(v -> {
            game.renderer.interiorCamera = !game.renderer.interiorCamera;
            camera.setText(game.renderer.interiorCamera ? "📷 داخلية" : "📷 خارجية");
        });

        TextView wheel = new TextView(this);
        wheel.setText("◉");
        wheel.setTextColor(Color.WHITE); wheel.setTextSize(52); wheel.setGravity(Gravity.CENTER);
        wheel.setBackground(round(0xAA273746));
        FrameLayout.LayoutParams wp = new FrameLayout.LayoutParams(142,142,Gravity.LEFT|Gravity.BOTTOM);
        wp.leftMargin=126; wp.bottomMargin=40; root.addView(wheel,wp);
        wheel.setOnTouchListener((v,e) -> {
            if(e.getAction()==MotionEvent.ACTION_DOWN || e.getAction()==MotionEvent.ACTION_MOVE) {
                float center=v.getWidth()/2f;
                float dx=(e.getX()-center)/center;
                game.steer=Math.max(-1f,Math.min(1f,dx));
            } else if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) game.steer=0;
            return true;
        });
        // Radio shortcut and compact in-game radio panel.
        TextView radioToggle = new TextView(this);
        radioToggle.setText("♫ الراديو");
        radioToggle.setTextColor(Color.WHITE); radioToggle.setTextSize(13); radioToggle.setTypeface(null,Typeface.BOLD);
        radioToggle.setGravity(Gravity.CENTER); radioToggle.setPadding(16,10,16,10);
        radioToggle.setBackground(round(0xDD176B45));
        FrameLayout.LayoutParams rtp = new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.RIGHT);
        rtp.rightMargin=18; rtp.topMargin=124; root.addView(radioToggle,rtp);

        radioPanel = new LinearLayout(this);
        radioPanel.setOrientation(LinearLayout.VERTICAL);
        radioPanel.setPadding(14,12,14,12);
        radioPanel.setGravity(Gravity.CENTER);
        radioPanel.setBackground(round(0xEE17242B));
        radioPanel.setVisibility(View.GONE);
        FrameLayout.LayoutParams rpp = new FrameLayout.LayoutParams(310,-2,Gravity.TOP|Gravity.RIGHT);
        rpp.rightMargin=18; rpp.topMargin=174; root.addView(radioPanel,rpp);

        TextView radioTitle = new TextView(this);
        radioTitle.setText("📻 راديو الميكروباص");
        radioTitle.setTextColor(0xFFFFD166); radioTitle.setTextSize(16); radioTitle.setTypeface(null,Typeface.BOLD);
        radioTitle.setGravity(Gravity.CENTER);
        radioPanel.addView(radioTitle,new LinearLayout.LayoutParams(-1,-2));

        radioTrackLabel = new TextView(this);
        radioTrackLabel.setText("اختار أغاني من موبايلك");
        radioTrackLabel.setTextColor(Color.WHITE); radioTrackLabel.setTextSize(12);
        radioTrackLabel.setGravity(Gravity.CENTER); radioTrackLabel.setPadding(4,10,4,10);
        radioPanel.addView(radioTrackLabel,new LinearLayout.LayoutParams(-1,-2));

        TextView chooseTracks = new TextView(this);
        chooseTracks.setText("＋ اختيار أغاني");
        chooseTracks.setTextColor(Color.WHITE); chooseTracks.setTextSize(13); chooseTracks.setGravity(Gravity.CENTER);
        chooseTracks.setPadding(10,10,10,10); chooseTracks.setBackground(round(0xFF287D55));
        LinearLayout.LayoutParams ctp = new LinearLayout.LayoutParams(-1,-2);
        ctp.bottomMargin=8; radioPanel.addView(chooseTracks,ctp);
        chooseTracks.setOnClickListener(v -> {
            Intent pick = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            pick.setType("audio/*");
            pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
            pick.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(Intent.createChooser(pick,"اختار ملفات الأغاني"),4201);
        });

        LinearLayout radioControls = new LinearLayout(this);
        radioControls.setOrientation(LinearLayout.HORIZONTAL);
        radioControls.setGravity(Gravity.CENTER);
        radioPanel.addView(radioControls,new LinearLayout.LayoutParams(-1,-2));
        TextView previousTrack = radioButton("⏮ السابق",0xFF34495E);
        radioControls.addView(previousTrack,new LinearLayout.LayoutParams(0,52,1));
        TextView playPause = radioButton("▶ تشغيل",0xFF176B45);
        radioPlayButton = playPause;
        LinearLayout.LayoutParams playLp = new LinearLayout.LayoutParams(0,52,1);
        playLp.leftMargin=6; playLp.rightMargin=6; radioControls.addView(playPause,playLp);
        TextView nextTrack = radioButton("التالي ⏭",0xFF34495E);
        radioControls.addView(nextTrack,new LinearLayout.LayoutParams(0,52,1));
        previousTrack.setOnClickListener(v -> changeRadioTrack(-1));
        nextTrack.setOnClickListener(v -> changeRadioTrack(1));
        playPause.setOnClickListener(v -> toggleRadioPlayback());

        TextView closeRadio = new TextView(this);
        closeRadio.setText("إغلاق");
        closeRadio.setTextColor(0xFFCCD6DD); closeRadio.setTextSize(12); closeRadio.setGravity(Gravity.CENTER);
        closeRadio.setPadding(10,8,10,2);
        radioPanel.addView(closeRadio,new LinearLayout.LayoutParams(-1,-2));
        closeRadio.setOnClickListener(v -> radioPanel.setVisibility(View.GONE));
        radioToggle.setOnClickListener(v -> radioPanel.setVisibility(radioPanel.getVisibility()==View.VISIBLE?View.GONE:View.VISIBLE));

        setContentView(root);
    }

    private TextView radioButton(String text, int color) {
        TextView button = new TextView(this);
        button.setText(text); button.setTextColor(Color.WHITE); button.setTextSize(12);
        button.setTypeface(null,Typeface.BOLD); button.setGravity(Gravity.CENTER);
        button.setPadding(4,8,4,8); button.setBackground(round(color));
        return button;
    }

    private void toggleRadioPlayback() {
        if (radioTracks.isEmpty()) {
            Toast.makeText(this,"اختار أغاني الأول من زر اختيار أغاني",Toast.LENGTH_SHORT).show();
            return;
        }
        if (radioPlayer != null && radioPlayer.isPlaying()) {
            radioPlayer.pause();
            radioPlayButton.setText("▶ تشغيل");
            return;
        }
        if (radioPlayer != null && !radioPreparing) {
            try { radioPlayer.start(); radioPlayButton.setText("⏸ إيقاف مؤقت"); }
            catch (Exception e) { playRadioTrack(radioIndex); }
        } else {
            playRadioTrack(radioIndex);
        }
    }

    private void changeRadioTrack(int delta) {
        if (radioTracks.isEmpty()) {
            Toast.makeText(this,"اختار أغاني الأول",Toast.LENGTH_SHORT).show();
            return;
        }
        radioIndex = (radioIndex + delta + radioTracks.size()) % radioTracks.size();
        playRadioTrack(radioIndex);
    }

    private void playRadioTrack(int index) {
        if (radioTracks.isEmpty()) return;
        radioIndex = (index + radioTracks.size()) % radioTracks.size();
        if (radioPlayer != null) {
            try { radioPlayer.stop(); } catch (Exception ignored) {}
            try { radioPlayer.release(); } catch (Exception ignored) {}
            radioPlayer = null;
        }
        radioPreparing = true;
        Uri uri = radioTracks.get(radioIndex);
        String name = "أغنية " + (radioIndex+1) + " / " + radioTracks.size();
        radioTrackLabel.setText("جاري تجهيز " + name);
        radioPlayButton.setText("…");
        try {
            radioPlayer = new MediaPlayer();
            radioPlayer.setAudioAttributes(new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            radioPlayer.setDataSource(this,uri);
            radioPlayer.setOnPreparedListener(mp -> {
                radioPreparing = false;
                mp.start();
                radioPlayButton.setText("⏸ إيقاف مؤقت");
                radioTrackLabel.setText("تشغيل " + name);
            });
            radioPlayer.setOnCompletionListener(mp -> changeRadioTrack(1));
            radioPlayer.setOnErrorListener((mp,what,extra) -> {
                radioPreparing = false;
                radioTrackLabel.setText("تعذر تشغيل الملف؛ جرّب ملفًا آخر");
                radioPlayButton.setText("▶ تشغيل");
                return true;
            });
            radioPlayer.prepareAsync();
        } catch (Exception e) {
            radioPreparing = false;
            radioTrackLabel.setText("تعذر فتح ملف الصوت");
            radioPlayButton.setText("▶ تشغيل");
        }
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==4201 && resultCode==RESULT_OK && data!=null) {
            ArrayList<Uri> picked = new ArrayList<>();
            try {
                if (data.getClipData()!=null) {
                    ClipData clips=data.getClipData();
                    for(int i=0;i<clips.getItemCount();i++) picked.add(clips.getItemAt(i).getUri());
                } else if (data.getData()!=null) picked.add(data.getData());
                for(Uri uri:picked) {
                    try { getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION); }
                    catch(Exception ignored) {}
                    if(!radioTracks.contains(uri)) radioTracks.add(uri);
                }
                if(!picked.isEmpty()) {
                    radioIndex=Math.max(0,radioTracks.size()-picked.size());
                    radioTrackLabel.setText("تم اختيار "+radioTracks.size()+" أغنية");
                    playRadioTrack(radioIndex);
                }
            } catch(Exception e) {
                Toast.makeText(this,"حصلت مشكلة في اختيار الأغاني",Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override protected void onDestroy() {
        releaseRadioPlayer();
        super.onDestroy();
    }

    private void releaseRadioPlayer() {
        if(radioPlayer!=null) {
            try { radioPlayer.stop(); } catch(Exception ignored) {}
            try { radioPlayer.release(); } catch(Exception ignored) {}
            radioPlayer=null;
        }
        radioPreparing=false;
    }

    @Override protected void onResume() {
        super.onResume();
        if (game != null) { game.onResume(); game.startEngineSound(); }
    }
    @Override protected void onPause() {
        if (radioPlayer != null && radioPlayer.isPlaying()) {
            try { radioPlayer.pause(); if (radioPlayButton != null) radioPlayButton.setText("▶ تشغيل"); } catch(Exception ignored) {}
        }
        if (game != null) game.stopEngineSound();
        if (game != null) game.onPause();
        super.onPause();
    }
    GradientDrawable round(int c) { GradientDrawable d=new GradientDrawable(); d.setColor(c); d.setCornerRadius(24); d.setStroke(2,0x88FFFFFF); return d; }

    static class GameView extends GLSurfaceView {
        GameRenderer renderer; volatile boolean gas=false, brake=false; volatile int gear=0; volatile float steer=0; float downX; TextView statusLabel; TextView rpmLabel;
        private EngineSound engineSound;
        GameView(Context c) { super(c); setEGLContextClientVersion(2); renderer=new GameRenderer(this); setRenderer(renderer); setRenderMode(RENDERMODE_CONTINUOUSLY); engineSound = new EngineSound(this); }
        void startEngineSound() { if (engineSound != null) engineSound.start(); }
        void stopEngineSound() { if (engineSound != null) engineSound.stop(); }
        @Override public boolean onTouchEvent(MotionEvent e) {
            if (e.getX() < getWidth()*0.52f && e.getY() < getHeight()*0.65f) {
                if(e.getAction()==MotionEvent.ACTION_DOWN) downX=e.getX();
                if(e.getAction()==MotionEvent.ACTION_MOVE) steer=Math.max(-1,Math.min(1,(e.getX()-downX)/(getWidth()*0.18f)));
                if(e.getAction()==MotionEvent.ACTION_UP || e.getAction()==MotionEvent.ACTION_CANCEL) steer=0;
            }
            return true;
        }
    }

    /**
     * Small synthesized engine loop. No audio files or extra permissions are required.
     * Pitch and load follow vehicle speed, throttle, and gear.
     */
    static class EngineSound {
        private final GameView game;
        private volatile boolean running = false;
        private Thread thread;
        private AudioTrack track;
        private static final int SAMPLE_RATE = 22050;
        private static final int BUFFER_SAMPLES = 1024;

        EngineSound(GameView game) { this.game = game; }

        synchronized void start() {
            if (running) return;
            running = true;
            thread = new Thread(this::audioLoop, "MicrobusEngineAudio");
            thread.start();
        }

        synchronized void stop() {
            running = false;
            if (track != null) {
                try { track.pause(); track.flush(); } catch (Exception ignored) {}
            }
            if (thread != null) {
                try { thread.join(250); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
                thread = null;
            }
            if (track != null) {
                try { track.stop(); } catch (Exception ignored) {}
                try { track.release(); } catch (Exception ignored) {}
                track = null;
            }
        }

        private void audioLoop() {
            int min = AudioTrack.getMinBufferSize(SAMPLE_RATE, AudioFormat.CHANNEL_OUT_MONO,
                    AudioFormat.ENCODING_PCM_16BIT);
            int bytes = Math.max(min, BUFFER_SAMPLES * 2 * 4);
            AudioTrack local = null;
            try {
                AudioAttributes attrs = new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_GAME)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build();
                AudioFormat format = new AudioFormat.Builder()
                        .setSampleRate(SAMPLE_RATE)
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build();
                local = new AudioTrack(attrs, format, bytes, AudioTrack.MODE_STREAM,
                        android.media.AudioManager.AUDIO_SESSION_ID_GENERATE);
                track = local;
                local.setVolume(0.62f);
                local.play();

                short[] samples = new short[BUFFER_SAMPLES];
                double phase = 0.0;
                double phase2 = 0.0;
                while (running) {
                    float speed = Math.abs(game.renderer.speed);
                    boolean throttle = game.gas;
                    int gear = game.gear;
                    // Idle rumble with a stronger rev when accelerating; neutral can rev too.
                    double rpmFactor = Math.min(1.0, speed / 20.0);
                    double baseHz = 62.0 + rpmFactor * 78.0 + (throttle ? 38.0 : 0.0);
                    if (gear == 0 && throttle) baseHz += 22.0;
                    if (gear == 3) baseHz = Math.max(48.0, baseHz * 0.82);
                    double wobble = throttle ? 2.8 : 1.0;
                    double gain = 0.16 + (throttle ? 0.08 : 0.0);
                    if (game.brake && speed > 1.0f) gain *= 0.88;

                    for (int i = 0; i < samples.length; i++) {
                        double hz = baseHz + Math.sin(phase2) * wobble;
                        phase += 2.0 * Math.PI * hz / SAMPLE_RATE;
                        phase2 += 2.0 * Math.PI * 3.1 / SAMPLE_RATE;
                        if (phase > Math.PI * 2.0) phase -= Math.PI * 2.0;
                        if (phase2 > Math.PI * 2.0) phase2 -= Math.PI * 2.0;
                        // A few harmonics make the tone less like a pure beep.
                        double tone = Math.sin(phase) * 0.72
                                + Math.sin(phase * 2.0) * 0.20
                                + Math.sin(phase * 3.0) * 0.08;
                        // Gentle low-frequency vibration.
                        tone += Math.sin(phase * 0.5) * 0.08;
                        samples[i] = (short) (Math.max(-1.0, Math.min(1.0, tone * gain)) * 32767);
                    }
                    int written = local.write(samples, 0, samples.length);
                    if (written < 0) break;
                }
            } catch (Exception ignored) {
                // Audio is optional: gameplay should continue if the device audio API fails.
            } finally {
                if (local != null) {
                    try { local.pause(); } catch (Exception ignored) {}
                    try { local.flush(); } catch (Exception ignored) {}
                    try { local.release(); } catch (Exception ignored) {}
                }
                track = null;
                running = false;
            }
        }
    }

    static class GameRenderer implements Renderer {
        GameView view; int program; int posLoc,colLoc,mvpLoc; FloatBuffer cube; float[] projection=new float[16], viewM=new float[16], model=new float[16], mvp=new float[16];
        float distance=0, lateral=0; volatile float speed=0; volatile boolean interiorCamera=false; long last=System.nanoTime();
        float collisionCooldown=0; long collisionUntil=0;
        float suspensionImpulse=0f;
        float trafficLightClock=0f;
        GameRenderer(GameView v){view=v; cube=makeCube();}
        public void onSurfaceCreated(GL10 gl,EGLConfig cfg) {
            GLES20.glClearColor(0.56f,0.78f,0.93f,1); GLES20.glEnable(GLES20.GL_DEPTH_TEST);
            String vs="attribute vec3 aPos; uniform mat4 uMVP; void main(){gl_Position=uMVP*vec4(aPos,1.0);}";
            String fs="precision mediump float; uniform vec4 uColor; void main(){gl_FragColor=uColor;}";
            int vsh=shader(GLES20.GL_VERTEX_SHADER,vs), fsh=shader(GLES20.GL_FRAGMENT_SHADER,fs);
            program=GLES20.glCreateProgram(); GLES20.glAttachShader(program,vsh); GLES20.glAttachShader(program,fsh); GLES20.glLinkProgram(program);
            posLoc=GLES20.glGetAttribLocation(program,"aPos"); colLoc=GLES20.glGetUniformLocation(program,"uColor"); mvpLoc=GLES20.glGetUniformLocation(program,"uMVP");
        }
        int shader(int type,String src){int s=GLES20.glCreateShader(type);GLES20.glShaderSource(s,src);GLES20.glCompileShader(s);return s;}
        public void onSurfaceChanged(GL10 gl,int w,int h){GLES20.glViewport(0,0,w,h);Matrix.perspectiveM(projection,0,60f,(float)w/Math.max(1,h),0.1f,250f);}
        public void onDrawFrame(GL10 gl){
            long now=System.nanoTime(); float dt=Math.min(.05f,(now-last)/1e9f); last=now;
            float routeProgressForPhysics = Math.max(0f, distance);
            boolean inCity = routeProgressForPhysics < 185f;
            float maxSpeed = view.gear==1 ? (inCity?6.5f:9f) : view.gear==2 ? (inCity?12f:19f) : view.gear==3 ? 5f : 0f;
            if(view.gear==3) {
                if(view.gas) speed=Math.max(-5f,speed-dt*4.5f); else speed=Math.min(0,speed+dt*2f);
            } else if(view.gear==0) {
                speed=Math.max(0,speed-dt*3f);
            } else if(view.gas) speed=Math.min(maxSpeed,speed+dt*(view.gear==1?4.0f:6.0f));
            else speed=Math.max(0,speed-dt*1.2f);
            if(view.brake) {
                speed = speed>0 ? Math.max(0,speed-dt*18f) : Math.min(0,speed+dt*18f);
                suspensionImpulse = Math.min(1.0f, suspensionImpulse + dt*1.7f);
            }
            suspensionImpulse = Math.max(0f, suspensionImpulse-dt*1.8f);
            collisionCooldown = Math.max(0f, collisionCooldown-dt);
            for(int i=0;i<9;i++) {
                float tz = -18f - i*21f + (float)(((distance*(0.65f + (i%3)*0.18f) + i*7f) % 150f));
                if(tz > 8f) tz -= 150f;
                float lane = (i%3==0) ? -2.45f : ((i%3==1) ? 2.45f : 0.15f);
                if(Math.abs(tz-1.1f)<2.4f && Math.abs(lateral-lane)<1.45f && Math.abs(speed)>2.0f && collisionCooldown<=0f) {
                    speed = Math.max(0f, speed*0.52f);
                    suspensionImpulse = 1.0f;
                    lateral += (lateral <= lane ? -0.35f : 0.35f);
                    lateral=Math.max(-3.1f,Math.min(3.1f,lateral));
                    collisionUntil=System.currentTimeMillis()+1400;
                    collisionCooldown=1.1f;
                }
            }
            // Slightly heavier, slower steering in town; more stable at highway speed.
            distance += speed*dt;
            float steerResponse = inCity ? 4.25f : 3.65f;
            lateral += view.steer*dt*steerResponse*(1.0f-Math.min(0.42f,Math.abs(speed)/48f));
            lateral=Math.max(-3.1f,Math.min(3.1f,lateral));
            // Traffic signals: slow the bus near a red light in the Cairo section.
            trafficLightClock += dt;
            if (inCity && trafficLightClock % 28f > 0.5f && trafficLightClock % 28f < 5.5f
                    && Math.abs(distance % 70f) < 1.5f && speed > 3.0f) {
                speed = Math.max(2.0f, speed-dt*5.5f);
            }
            // City speed humps take a little momentum off the microbus.
            if (inCity && Math.abs(speed)>2.0f) {
                float humpPhase = (Math.abs(distance)+24f)%32f;
                if (humpPhase < 0.55f && collisionCooldown<=0f) {
                    speed *= 0.90f;
                    suspensionImpulse = Math.max(suspensionImpulse,0.48f);
                    collisionCooldown = 0.45f;
                }
            }
            if(view.statusLabel!=null) {
                final String msg = System.currentTimeMillis()<collisionUntil
                    ? "⚠ خبطة! السرعة: "+Math.max(0,(int)(Math.abs(speed)*5))+" كم/س"
                    : (Math.max(0f,distance)<185f ? "شوارع القاهرة" : Math.max(0f,distance)<280f ? "مخرج القاهرة • الصحراوي" : "طريق إسكندرية الصحراوي")
                      +"  •  "+Math.max(0,(int)(Math.abs(speed)*5))+" كم/س  •  "+(view.gear==0?"N":view.gear==1?"1":view.gear==2?"2":"R");
                view.statusLabel.post(() -> view.statusLabel.setText(msg));
            }
            if(view.rpmLabel!=null) {
                float throttleLoad = view.gas ? 0.28f : 0f;
                float rpmValue = Math.min(1f, 0.12f + Math.abs(speed)/22f + throttleLoad);
                int bars = Math.max(1, Math.min(6, Math.round(rpmValue*6f)));
                StringBuilder meter = new StringBuilder("RPM  ");
                for(int k=0;k<6;k++) meter.append(k<bars ? "▰" : "▱");
                final String rpmText = meter.toString() + "  " + (int)(850 + rpmValue*3850) + " دورة/دقيقة";
                view.rpmLabel.post(() -> view.rpmLabel.setText(rpmText));
            }
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT|GLES20.GL_DEPTH_BUFFER_BIT); GLES20.glUseProgram(program);
            if(interiorCamera) {
                // Driver-eye camera: lower and closer to the windshield.
                Matrix.setLookAtM(viewM,0,lateral+0.0f,2.15f,2.1f,lateral,1.65f,-12.0f,0,1,0);
            } else {
                Matrix.setLookAtM(viewM,0,lateral+0.0f,5.2f,10.5f,lateral,1.0f,-3.0f,0,1,0);
            }
            // Egyptian route: busy Cairo streets fade into the sandy Alexandria desert road.
            float routeProgress = Math.max(0f, distance);
            float urban = routeProgress < 170f ? 1f : routeProgress < 280f ? (280f-routeProgress)/110f : 0f;
            float groundR = 0.78f, groundG = 0.68f, groundB = 0.49f;
            draw(0,-1.0f,-80,100,0.15f,230,groundR,groundG,groundB);
            float roadHalf = 4.75f - urban*0.45f;
            draw(0,-0.82f,-80,roadHalf*2f,0.18f,230,0.19f,0.20f,0.21f);
            draw(-roadHalf-0.55f,-0.79f,-80,1.0f,0.13f,230,urban*0.52f+0.20f,urban*0.49f+0.22f,urban*0.43f+0.22f);
            draw(roadHalf+0.55f,-0.79f,-80,1.0f,0.13f,230,urban*0.52f+0.20f,urban*0.49f+0.22f,urban*0.43f+0.22f);
            if (urban > 0.05f) {
                // Cairo-style raised sidewalks and worn curb paint.
                draw(-roadHalf-1.05f,-0.67f,-80,0.85f,0.18f,230,0.57f,0.54f,0.48f);
                draw( roadHalf+1.05f,-0.67f,-80,0.85f,0.18f,230,0.57f,0.54f,0.48f);
                for (int c=0;c<28;c++) {
                    float cz=-c*8f+(((distance%8f)+8f)%8f);
                    float curbColor=(c%2==0)?0.82f:0.72f;
                    draw(-roadHalf-1.05f,-0.55f,cz,0.80f,0.06f,1.8f,curbColor,0.75f,0.62f);
                    draw( roadHalf+1.05f,-0.55f,cz,0.80f,0.06f,1.8f,curbColor,0.75f,0.62f);
                }
            }
            // moving dashed lane markers
            float offset=((distance%12)+12)%12;
            for(int i=0;i<22;i++){float z=-i*10+(offset); draw(0,-0.70f,z,0.13f,0.035f,4.3f,0.94f,0.88f,0.63f);}
            if (urban > 0.15f) {
                draw(-1.72f,-0.695f,-80,0.07f,0.025f,220,0.88f,0.78f,0.46f);
                draw( 1.72f,-0.695f,-80,0.07f,0.025f,220,0.88f,0.78f,0.46f);
            }
            // Reflective lane studs and desert highway lighting.
            if (urban < 0.3f) {
                for(int marker=0;marker<18;marker++) {
                    float mz=-marker*12f+(((distance%12f)+12f)%12f);
                    draw(-4.50f,-0.69f,mz,0.12f,0.035f,0.22f,0.93f,0.84f,0.52f);
                    draw( 4.50f,-0.69f,mz,0.12f,0.035f,0.22f,0.93f,0.84f,0.52f);
                }
                for(int lamp=0;lamp<10;lamp++) {
                    float lz=-lamp*25f+(((distance%25f)+25f)%25f);
                    float lx=(lamp%2==0)?-7.0f:7.0f;
                    draw(lx,2.2f,lz,0.12f,4.4f,0.12f,0.40f,0.40f,0.36f);
                    draw(lx*0.96f,4.35f,lz,0.65f,0.10f,0.12f,0.38f,0.39f,0.34f);
                    draw(lx*0.92f,4.27f,lz,0.25f,0.08f,0.22f,0.98f,0.80f,0.48f);
                }
            }
            // Traffic mix inspired by Egypt: Cairo black/white taxis, private sedans,
            // white-and-green microbuses and small delivery vans.
            for(int i=0;i<11;i++){
                float z = -16f - i*17.5f + (float)(((distance*(0.62f + (i%3)*0.16f) + i*9f) % 165f));
                if(z > 9f) z -= 165f;
                float lane = (i%3==0) ? -2.45f : ((i%3==1) ? 2.45f : 0.15f);
                if(Math.abs(z-1.1f)<12f && Math.abs(lateral-lane)<2.0f) lane += (lane <= lateral ? -1.0f : 1.0f);
                float tx = lane + (float)Math.sin(distance*0.012f+i*1.7f)*0.18f;
                boolean taxi = i%5==0;
                boolean micro = i%5==2;
                boolean van = i%5==4;
                float cr = taxi ? 0.90f : micro ? 0.88f : van ? 0.76f : ((i%3==0)?0.18f:0.70f);
                float cg = taxi ? 0.88f : micro ? 0.90f : van ? 0.78f : ((i%3==0)?0.22f:0.72f);
                float cb = taxi ? 0.84f : micro ? 0.82f : van ? 0.72f : ((i%3==0)?0.25f:0.78f);
                float length = micro ? 2.85f : van ? 2.45f : 2.35f;
                float height = micro ? 1.12f : van ? 0.90f : 0.72f;
                draw(tx,0.43f,z,1.48f,height,length,cr,cg,cb);
                draw(tx,0.43f+height*0.48f,z-0.08f,1.22f,micro?0.72f:0.40f,micro?1.42f:1.20f,0.18f,0.29f,0.35f);
                if(taxi) {
                    // Traditional Cairo taxi contrast stripe and roof marker.
                    draw(tx,0.49f,z+0.03f,1.50f,0.19f,length*0.88f,0.12f,0.13f,0.13f);
                    draw(tx,1.02f,z-0.05f,0.38f,0.12f,0.28f,0.92f,0.86f,0.58f);
                } else if(micro) {
                    draw(tx,0.58f,z+0.02f,1.51f,0.19f,length*0.88f,0.10f,0.43f,0.24f);
                    draw(tx-0.46f,0.96f,z+0.35f,0.30f,0.38f,0.06f,0.17f,0.33f,0.39f);
                    draw(tx+0.46f,0.96f,z+0.35f,0.30f,0.38f,0.06f,0.17f,0.33f,0.39f);
                }
                draw(tx-0.43f,0.83f,z+length*0.26f,0.27f,0.20f,0.05f,0.10f,0.16f,0.20f);
                draw(tx+0.43f,0.83f,z+length*0.26f,0.27f,0.20f,0.05f,0.10f,0.16f,0.20f);
                draw(tx-0.55f,0.35f,z+length*0.48f,0.22f,0.16f,0.06f,0.82f,0.12f,0.08f);
                draw(tx+0.55f,0.35f,z+length*0.48f,0.22f,0.16f,0.06f,0.82f,0.12f,0.08f);
                draw(tx,0.28f,z+length*0.50f,0.36f,0.15f,0.05f,0.92f,0.84f,0.58f);
                for(int side=-1;side<=1;side+=2) {
                    draw(tx+side*0.72f,0.13f,z-length*0.28f,0.16f,0.30f,0.42f,0.06f,0.06f,0.06f);
                    draw(tx+side*0.72f,0.13f,z+length*0.28f,0.16f,0.30f,0.42f,0.06f,0.06f,0.06f);
                    draw(tx+side*0.72f,0.13f,z-length*0.28f,0.07f,0.12f,0.16f,0.42f,0.43f,0.43f);
                }
            }
            // Egyptian roadside set dressing: Cairo apartment blocks, shops, balconies,
            // street lamps and palms near the start; scattered palms and desert markers later.
            for(int i=0;i<24;i++){
                float z=-(i*10.5f)+(((distance%10.5f)+10.5f)%10.5f);
                float side=(i%2==0)?-1:1;
                float x=side*(urban>0.15f ? 7.0f+(i%3)*1.75f : 8.0f+(i%3)*2.8f);
                if (urban > 0.12f && i%4!=3) {
                    float floors = 2.3f + (i%3)*0.65f;
                    float bw=2.5f+(i%2)*0.75f;
                    float sand=(i%3==0)?0.72f:((i%3==1)?0.80f:0.67f);
                    // Main plaster facade and rooftop water tank.
                    draw(x,floors*0.48f,z,bw,floors,2.7f,sand,sand*0.91f,sand*0.77f);
                    draw(x,floors+0.12f,z,bw+0.15f,0.18f,2.85f,0.52f,0.46f,0.37f);
                    draw(x+0.35f,floors+0.48f,z-0.20f,0.42f,0.42f,0.42f,0.24f,0.31f,0.34f);
                    // Rows of blue-tinted windows and projecting balconies.
                    for(int fl=0;fl<3;fl++) {
                        float wy=0.48f+fl*0.76f;
                        draw(x-bw*0.23f,wy,z+1.39f,0.42f,0.42f,0.07f,0.18f,0.37f,0.47f);
                        draw(x+bw*0.23f,wy,z+1.39f,0.42f,0.42f,0.07f,0.18f,0.37f,0.47f);
                        if (fl < 2) {
                            draw(x,wy-0.20f,z+1.48f,bw*0.74f,0.08f,0.22f,0.57f,0.55f,0.49f);
                            draw(x,wy-0.05f,z+1.58f,bw*0.70f,0.05f,0.05f,0.25f,0.27f,0.27f);
                        }
                    }
                    // Small rooftop satellite dishes and external AC boxes: familiar Cairo details.
                    if (i%2==0) {
                        draw(x-bw*0.30f,floors+0.32f,z+0.12f,0.20f,0.07f,0.20f,0.72f,0.73f,0.69f);
                        draw(x-bw*0.30f,floors+0.45f,z+0.12f,0.04f,0.18f,0.04f,0.50f,0.50f,0.47f);
                    }
                    draw(x+bw*0.35f,1.55f,z+1.48f,0.28f,0.25f,0.12f,0.76f,0.77f,0.73f);
                    // Ground-floor shopfront, colorful awning and signboard.
                    draw(x,0.43f,z+1.42f,bw*0.72f,0.72f,0.08f,0.19f,0.28f,0.30f);
                    float sr=(i%3==0)?0.72f:((i%3==1)?0.12f:0.84f);
                    float sg=(i%3==0)?0.16f:((i%3==1)?0.40f:0.68f);
                    float sb=(i%3==0)?0.12f:((i%3==1)?0.20f:0.18f);
                    draw(x,1.02f,z+1.48f,bw*0.90f,0.24f,0.10f,sr,sg,sb);
                    for(int aw=0;aw<5;aw++)
                        draw(x-bw*0.42f+aw*bw*0.21f,0.78f,z+1.58f,bw*0.19f,0.12f,0.10f,
                            aw%2==0?0.92f:0.88f,aw%2==0?0.86f:0.20f,0.66f);
                } else if (urban > 0.12f && i%4==3) {
                    // Street lamps and utility poles in the city.
                    draw(x,1.65f,z,0.12f,3.2f,0.12f,0.22f,0.23f,0.22f);
                    draw(x-side*0.35f,3.2f,z,0.75f,0.10f,0.12f,0.24f,0.24f,0.22f);
                    draw(x-side*0.60f,3.13f,z,0.28f,0.10f,0.20f,0.98f,0.78f,0.42f);
                } else {
                    // Highway palms with layered fronds and occasional roadside posts.
                    draw(x,0.90f,z,0.24f,1.8f,0.24f,0.43f,0.28f,0.13f);
                    draw(x,1.92f,z,1.05f,0.28f,0.35f,0.16f,0.39f,0.17f);
                    draw(x-0.38f,1.76f,z,0.72f,0.18f,0.25f,0.20f,0.44f,0.18f);
                    draw(x+0.38f,1.76f,z,0.72f,0.18f,0.25f,0.18f,0.35f,0.14f);
                    draw(x,2.08f,z-0.20f,0.22f,0.13f,0.70f,0.19f,0.43f,0.17f);
                    if (i%3==0) {
                        draw(side*6.25f,0.55f,z,0.18f,1.1f,0.18f,0.82f,0.80f,0.69f);
                        draw(side*6.25f,1.18f,z,0.62f,0.28f,0.18f,0.10f,0.42f,0.27f);
                    }
                }
            }
            // Cairo intersection markings and a roadside signal that cycles red/amber/green.
            if (urban > 0.15f) {
                float crossZ=-32f+(((distance%70f)+70f)%70f);
                if(crossZ>8f) crossZ-=70f;
                for(int stripe=0;stripe<9;stripe++) {
                    draw(-3.5f+stripe*0.88f,-0.685f,crossZ,0.55f,0.025f,1.15f,0.88f,0.87f,0.80f);
                }
                float signalPhase=trafficLightClock%12f;
                float red=signalPhase<5.5f?0.95f:0.16f;
                float amber=(signalPhase>=5.5f&&signalPhase<7f)?0.95f:0.18f;
                float green=signalPhase>=7f?0.88f:0.14f;
                draw(-5.25f,2.45f,crossZ,0.12f,4.4f,0.12f,0.23f,0.24f,0.22f);
                draw(-5.25f,4.55f,crossZ,0.40f,0.86f,0.25f,0.10f,0.11f,0.10f);
                draw(-5.25f,4.78f,crossZ+0.15f,0.22f,0.20f,0.04f,red,0.08f,0.05f);
                draw(-5.25f,4.52f,crossZ+0.15f,0.22f,0.20f,0.04f,amber,amber*0.48f,0.04f);
                draw(-5.25f,4.26f,crossZ+0.15f,0.22f,0.20f,0.04f,0.05f,green,0.08f);
            }
            // A large green Egyptian road sign visible on the route toward Alexandria.
            float signZ=-48f+(((distance%95f)+95f)%95f);
            if (signZ>5f) signZ-=95f;
            if (signZ < -8f) {
                draw(-5.4f,3.15f,signZ,0.16f,4.8f,0.18f,0.62f,0.62f,0.57f);
                draw( 5.4f,3.15f,signZ,0.16f,4.8f,0.18f,0.62f,0.62f,0.57f);
                draw(0,5.15f,signZ,11.4f,1.15f,0.22f,0.06f,0.35f,0.20f);
                draw(0,5.15f,signZ+0.14f,10.8f,0.82f,0.05f,0.10f,0.43f,0.25f);
            }
            // Small speed humps on Cairo streets: visible bands and a gentle physical slowdown.
            if (urban > 0.5f) {
                for(int h=0;h<3;h++) {
                    float hz=-24f-h*32f+(((distance%32f)+32f)%32f);
                    draw(0,-0.69f,hz,roadHalf*1.7f,0.045f,0.42f,0.77f,0.72f,0.60f);
                    for(int stripe=0;stripe<7;stripe++)
                        draw(-roadHalf*0.78f+stripe*roadHalf*0.26f,-0.66f,hz-0.02f,0.42f,0.025f,0.44f,0.12f,0.13f,0.13f);
                }
            }
            // Main player microbus: Egyptian white body, green stripe, chrome details,
            // front grille, mirrors, windows, door seams, yellow plate and moving suspension.
            float suspensionBob = (float)Math.sin(distance*1.25f)*Math.min(0.045f,Math.abs(speed)*0.0018f)
                    + (float)Math.sin(distance*0.42f)*0.018f - suspensionImpulse*0.055f;
            float busY = 0.65f + suspensionBob;
            float busRoll = -view.steer*2.4f*(Math.min(1f,Math.abs(speed)/10f));
            drawRotated(lateral,busY,1.1f,1.55f,1.05f,2.7f,0.91f,0.90f,0.82f,0,0,busRoll);
            drawRotated(lateral,1.05f+suspensionBob,0.35f,1.43f,0.22f,1.95f,0.12f,0.43f,0.26f,0,0,busRoll);
            // Split windshield with dark rubber border and a pair of wiper blades.
            draw(lateral,1.42f+suspensionBob,0.48f,-0.04f,1.2f,0.30f,0.12f,0.22f,0.27f);
            draw(lateral-0.30f,1.43f+suspensionBob,0.12f,0.54f,0.24f,0.035f,0.27f,0.43f,0.49f);
            draw(lateral+0.30f,1.43f+suspensionBob,0.12f,0.54f,0.24f,0.035f,0.27f,0.43f,0.49f);
            draw(lateral-0.28f,1.27f+suspensionBob,0.13f,0.48f,0.035f,0.035f,0.08f,0.09f,0.09f);
            draw(lateral+0.28f,1.27f+suspensionBob,0.13f,0.48f,0.035f,0.035f,0.08f,0.09f,0.09f);
            // Side passenger windows and sliding-door outline.
            for(int side=-1;side<=1;side+=2) {
                draw(lateral+side*0.785f,1.02f+suspensionBob,0.45f,0.055f,0.44f,0.62f,0.17f,0.32f,0.39f);
                draw(lateral+side*0.785f,1.02f+suspensionBob,-0.28f,0.055f,0.44f,0.62f,0.17f,0.32f,0.39f);
                draw(lateral+side*0.80f,0.63f+suspensionBob,-0.10f,0.035f,0.64f,0.04f,0.40f,0.39f,0.33f);
                draw(lateral+side*0.80f,0.65f+suspensionBob,0.70f,0.035f,0.66f,0.04f,0.40f,0.39f,0.33f);
                draw(lateral+side*0.82f,0.82f+suspensionBob,0.05f,0.06f,0.05f,0.14f,0.70f,0.68f,0.58f);
            }
            // Roof sign, mirror arms and mirror housings.
            draw(lateral,1.47f+suspensionBob,1.15f,0.72f,0.16f,0.24f,0.94f,0.94f,0.90f);
            draw(lateral,1.49f+suspensionBob,1.15f,0.56f,0.035f,0.18f,0.12f,0.43f,0.26f);
            draw(lateral-0.90f,1.05f+suspensionBob,0.10f,0.42f,0.06f,0.08f,0.15f,0.15f,0.14f);
            draw(lateral+0.90f,1.05f+suspensionBob,0.10f,0.42f,0.06f,0.08f,0.15f,0.15f,0.14f);
            draw(lateral-1.10f,1.00f+suspensionBob,0.10f,0.24f,0.18f,0.22f,0.09f,0.10f,0.10f);
            draw(lateral+1.10f,1.00f+suspensionBob,0.10f,0.24f,0.18f,0.22f,0.09f,0.10f,0.10f);
            // Front lights, black grille with vertical slats, bumper and Egyptian-style yellow plate.
            draw(lateral-0.92f,0.46f+suspensionBob,-0.24f,0.30f,0.16f,0.06f,0.98f,0.86f,0.50f);
            draw(lateral+0.92f,0.46f+suspensionBob,-0.24f,0.30f,0.16f,0.06f,0.98f,0.86f,0.50f);
            draw(lateral,0.45f+suspensionBob,-0.255f,0.78f,0.24f,0.05f,0.10f,0.11f,0.11f);
            for(int grill=0;grill<5;grill++)
                draw(lateral-0.29f+grill*0.145f,0.45f+suspensionBob,-0.29f,0.025f,0.19f,0.025f,0.48f,0.49f,0.45f);
            draw(lateral,0.20f+suspensionBob,-0.29f,0.60f,0.13f,0.05f,0.90f,0.75f,0.31f);
            draw(lateral,0.12f+suspensionBob,-0.32f,1.30f,0.14f,0.08f,0.18f,0.18f,0.18f);
            // Wheels with hubs; the rotation makes movement more legible.
            float wheelSpin = distance*34f;
            for(int side=-1;side<=1;side+=2) {
                drawRotated(lateral+side*1.18f,0.05f+suspensionBob,1.55f,0.26f,0.38f,0.52f,0.055f,0.055f,0.055f,wheelSpin,0,0);
                draw(lateral+side*1.18f,0.05f+suspensionBob,1.55f,0.13f,0.20f,0.54f,0.44f,0.45f,0.43f);
                drawRotated(lateral+side*1.18f,0.05f+suspensionBob,-0.15f,0.26f,0.38f,0.52f,0.055f,0.055f,0.055f,wheelSpin,0,0);
                draw(lateral+side*1.18f,0.05f+suspensionBob,-0.15f,0.13f,0.20f,0.54f,0.44f,0.45f,0.43f);
            }
            // Driver cabin: dashboard and steering wheel are drawn only in interior view.
            if(interiorCamera) {
                // Dashboard fascia across the lower windshield.
                draw(lateral,0.66f,1.45f,3.35f,0.42f,0.48f,0.08f,0.10f,0.10f);
                draw(lateral,0.90f,1.18f,1.00f,0.13f,0.16f,0.20f,0.22f,0.22f);
                draw(lateral-1.08f,0.73f,1.35f,0.36f,0.08f,0.28f,0.15f,0.17f,0.16f);
                draw(lateral+1.08f,0.73f,1.35f,0.36f,0.08f,0.28f,0.15f,0.17f,0.16f);
                // Center console, vents, radio and gear lever.
                draw(lateral+0.88f,0.54f,1.13f,0.42f,0.30f,0.18f,0.12f,0.13f,0.13f);
                for(int vent=0;vent<4;vent++)
                    draw(lateral+0.75f+vent*0.085f,0.61f,1.02f,0.035f,0.09f,0.025f,0.48f,0.50f,0.46f);
                draw(lateral+0.88f,0.43f,1.02f,0.23f,0.07f,0.025f,0.08f,0.42f,0.25f);
                draw(lateral+0.38f,0.50f,0.76f,0.06f,0.30f,0.06f,0.16f,0.16f,0.15f);
                draw(lateral+0.38f,0.66f,0.76f,0.12f,0.10f,0.12f,0.22f,0.22f,0.20f);
                // Instrument cluster with bright speed/RPM dials.
                draw(lateral-0.55f,1.02f,1.08f,0.28f,0.08f,0.035f,0.03f,0.04f,0.04f);
                draw(lateral-0.55f,1.07f,1.04f,0.19f,0.045f,0.025f,0.08f,0.75f,0.35f);
                draw(lateral+0.02f,1.02f,1.08f,0.28f,0.08f,0.035f,0.03f,0.04f,0.04f);
                draw(lateral+0.02f,1.07f,1.04f,0.19f,0.045f,0.025f,0.95f,0.65f,0.10f);
                // Steering column and simplified steering wheel rim made of small segments.
                draw(lateral-0.02f,0.72f,0.68f,0.12f,0.18f,0.26f,0.06f,0.07f,0.07f);
                for(int k=0;k<12;k++) {
                    double a=k*Math.PI/6.0;
                    float wx=lateral-0.02f+(float)Math.cos(a)*0.63f;
                    float wy=0.83f+(float)Math.sin(a)*0.36f;
                    draw(wx,wy,0.54f,0.10f,0.09f,0.10f,0.035f,0.04f,0.04f);
                }
                draw(lateral-0.02f,0.83f,0.53f,0.12f,0.12f,0.10f,0.05f,0.06f,0.06f);
                // Side pillars frame the windshield.
                draw(lateral-1.58f,1.70f,0.70f,0.10f,1.18f,0.12f,0.08f,0.09f,0.09f);
                draw(lateral+1.58f,1.70f,0.70f,0.10f,1.18f,0.12f,0.08f,0.09f,0.09f);
            }
        }
        void drawRotated(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b,
                         float rx,float ry,float rz) {
            Matrix.setIdentityM(model,0);
            Matrix.translateM(model,0,x,y,z);
            Matrix.rotateM(model,0,rx,1,0,0);
            Matrix.rotateM(model,0,ry,0,1,0);
            Matrix.rotateM(model,0,rz,0,0,1);
            Matrix.scaleM(model,0,sx,sy,sz);
            Matrix.multiplyMM(mvp,0,viewM,0,model,0); float[] out=new float[16]; Matrix.multiplyMM(out,0,projection,0,mvp,0);
            GLES20.glUniformMatrix4fv(mvpLoc,1,false,out,0); GLES20.glUniform4f(colLoc,r,g,b,1);
            GLES20.glEnableVertexAttribArray(posLoc); GLES20.glVertexAttribPointer(posLoc,3,GLES20.GL_FLOAT,false,0,cube);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36); GLES20.glDisableVertexAttribArray(posLoc);
        }
        void draw(float x,float y,float z,float sx,float sy,float sz,float r,float g,float b){
            Matrix.setIdentityM(model,0); Matrix.translateM(model,0,x,y,z); Matrix.scaleM(model,0,sx,sy,sz);
            Matrix.multiplyMM(mvp,0,viewM,0,model,0); float[] out=new float[16]; Matrix.multiplyMM(out,0,projection,0,mvp,0);
            GLES20.glUniformMatrix4fv(mvpLoc,1,false,out,0); GLES20.glUniform4f(colLoc,r,g,b,1);
            GLES20.glEnableVertexAttribArray(posLoc); GLES20.glVertexAttribPointer(posLoc,3,GLES20.GL_FLOAT,false,0,cube);
            GLES20.glDrawArrays(GLES20.GL_TRIANGLES,0,36); GLES20.glDisableVertexAttribArray(posLoc);
        }
        FloatBuffer makeCube(){
            float[] v={
            -0.5f,-0.5f,0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,-0.5f,0.5f, 0.5f,0.5f,0.5f, -0.5f,0.5f,0.5f,
            0.5f,-0.5f,-0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,-0.5f,-0.5f, -0.5f,0.5f,-0.5f, 0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, -0.5f,-0.5f,0.5f, -0.5f,0.5f,0.5f, -0.5f,-0.5f,-0.5f, -0.5f,0.5f,0.5f, -0.5f,0.5f,-0.5f,
            0.5f,-0.5f,0.5f, 0.5f,-0.5f,-0.5f, 0.5f,0.5f,-0.5f, 0.5f,-0.5f,0.5f, 0.5f,0.5f,-0.5f, 0.5f,0.5f,0.5f,
            -0.5f,0.5f,0.5f, 0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,0.5f, 0.5f,0.5f,-0.5f, -0.5f,0.5f,-0.5f,
            -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,-0.5f, 0.5f,-0.5f,0.5f, -0.5f,-0.5f,0.5f};
            ByteBuffer bb=ByteBuffer.allocateDirect(v.length*4).order(ByteOrder.nativeOrder()); FloatBuffer fb=bb.asFloatBuffer(); fb.put(v).position(0); return fb;
        }
    }
}
